import timeslots from "../lib/timeslots";
import {useState, useEffect} from "react"

const Reservation = () => {
  const [partySize, setPartySize] = useState(1)
  const [tableOptions, setTableOptions] = useState([])
  const Tables = [
      {
        "type": "small",
        "amount": 4,
        "maxPartySize": 2
      },
      {
        "type": "medium",
        "amount": 4,
        "maxPartySize": 4
      },
      {
        "type": "large",
        "amount": 4,
        "maxPartySize": 6
      }
]
  function submitForm(e) {
    e.preventDefault();
    let form = e.target
    // e.target refers to whatever the target the action happened on
    let data = Object.fromEntries(new FormData(form))
    console.log(data)
  }
  useEffect(() => {
    if(partySize <= 2){
      if(Tables[0].amount >= 1){
        setTableOptions([tableOptions, "small"]) //appends "small" to the end
      }
      if(Tables[1].amount >= 1){
        setTableOptions([tableOptions, "medium"]) //appends "medium" to the end
      }
      if(Tables[2].amount >= 1){
        setTableOptions([tableOptions, "large"]) //... means appends "large" to the end
      }
    }else if(partySize <= 4){
      if(Tables[1].amount >= 1){
        setTableOptions([tableOptions, "medium"]) //appends "medium" to the end
      }
      if(Tables[2].amount >= 1){
        setTableOptions([tableOptions, "large"]) //appends "large" to the end
      }
    }else if(partySize <= 6){
      if(Tables[2].amount >= 1){
        setTableOptions([tableOptions, "large"]) //appends "large" to the end
      }
    }else{
      //
    }
  },[
    partySize
  ])

  return (
	<div>
    <form onSubmit={submitForm}>
        {/* <div className="form-group">
          <label>Name</label>
          <input className="form-control" name="name" />
        </div>

        <div className="form-group">
          <label htmlFor="res-email">Email address</label>
          <input 
            id="res-email" 
            name="email" 
            className="form-control" 
            type="email"/>
          <span className="form-text">We'll never share your email with anyone else.</span>
        </div>

        <div className="form-group">
          <label>Phone Number</label>
          <input className="form-control" type="tel" name="phone" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" />
          <span className="form-text">(###)-###-####</span>
          
        </div> */}


      
        <div className="form-group">
          <label>Party Size</label>
          <input onChange={(e) => {setPartySize(e.target.value)}} value={partySize} className="form-control" type="number" min="1" max="100" />
        </div>

        <div className="form-group">
          <label>Select Table</label>
          <select>
            {tableOptions.map((val) => {
              return (<><option>{val}</option></>)
            })}
          </select>
        </div>
        
        <div className="form-group">
          <label>Select Date</label>
          <input type="date" />
          <select name="time" id="res.time">
            {timeslots.map(slot => {
              return (
                <option key={slot.time} value={slot.time}>{slot.time}</option>
              )
            })}
          </select>
        </div>

        <button className="btn">Submit</button>
    </form>
  </div>
  )
}

// Name, Contact info, Party size (number of guests), Date and time picker, some way to track already selected slots

export default Reservation;