// ./images/logo1.jpg

function Header() {
    return (
    <h1>
        
    </h1>
    );
  }

export default Header;