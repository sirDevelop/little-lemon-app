function Home() {
    return <h1>Hello world</h1>;
  }

export default Home;